// Copie para 'config.js' e edite a URL do Apps Script:
window.APP_CONFIG = {
  SCRIPT_URL: "https://script.google.com/macros/s/SEU_DEPLOY/exec"
};